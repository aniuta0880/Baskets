﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp4.Models
{
    public class Car
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Mark { get; set; }
        public double Engine { get; set; }
        public double Km { get; set; }
        public int GarageId { get; set; }//nazwa klasy + klucz główny w tej klase - zmienna która ma wskazywac na klucz obcy 
        public Garage Garage { get; set; }
    }
}

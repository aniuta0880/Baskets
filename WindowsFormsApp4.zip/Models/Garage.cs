﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsApp4.Models
{
    public class Garage
    {
        public int Id { get; set; } // zawsze - jako klucz główny 
        public string Name { get; set; }
        public string City { get; set; }
        public string Street { get; set; }
        public string StreetNumber { get; set; }

    }
}

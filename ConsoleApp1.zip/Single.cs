﻿namespace ConsoleApp1
{
    internal class Single
	{
		private static Single instance;
		private Single()
		{
			//konstruktor domyślny, a zaraz prywatny
		}
		public static Single Instance
		{
			get { if (instance == null)
					instance = new Single();
				return instance;
				}
			set { }
		}
	}

}


﻿namespace ConsoleApp1
{
    class Profesor
	{
		public string Imie { get; set; }
		public static string sImie { get; set; }
	}

}

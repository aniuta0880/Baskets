﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    /* public class Human
     {
         public Human(int age)
         {
             Age = age;
         }
         public int Age { get; set; }
         public DateTime BirthDate;
         public int howOldAreYou()
         {
             return Age;
         }
         public int howOldAreYou(string a)
         {
             return Age;
         }
         public int howOldAreYou(int a)
         {
             return Age;
         }//przeciążenie metod 

     }
     public class SuperStudent: Student
     { }
     public class Student: Human //klasa student dziedziczy po human age 
     {
         public Student():base(0)
         { }
         public string Nr { get; set; }
         public string Name { get; set; }
         public int Id { get; set; }
         public int NrAlbumu { get; set; }

     }
 }
 */

}
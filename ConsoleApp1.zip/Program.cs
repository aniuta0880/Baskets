﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;


namespace ConsoleApp1
{
	class School
	{
		public string schoolName { get; set; }
		//public List<Student> Students = new List<Student>();
	}

	class Student
	{
		public string Nr { get; set; }
		public string Name { get; set; }
		public int Id { get; set; }
		public int NrAlbumu { get; set; }
		//public Student()
		
	} 
	class Program
	{

		public static List<Student> students = new List<Student>();
		
		static string connectionString = "Data Source=DESKTOP-OFK5IM7\\SQLEXPRESS;Initial Catalog=DBSchool;Integrated Security=true";
		static SqlConnection sqlConnection = new SqlConnection(connectionString);

		static void Main(string[] args)
		{
			
			Student student = new Student();
			
			while (true)
			{
				Console.WriteLine(@"Wybierz jedną z opcji:
						1- wyświetl wszystkich
						2- wybierz studenta przez album
						3-dodaj nowego studenta
						4-mapuj studentow
						q- wyjdź
						");
				string option = Console.ReadLine(); 
				if (option == "q") break;
				if(option=="1")
				{
					ShowAllStudents();
				}
				if(option =="2")
				{
					Console.WriteLine("Podaj nr albumu studenta");
					int nr = int.Parse(Console.ReadLine());
					SearchByAlbum(nr);
				}
				if(option=="3")
				{
					InsertStudent();
				}
				if(option=="4")
				{
					MapStudents();

				}
			}
			
			//int nr = Convert.toInt32(Console.ReadLine());

			Console.ReadKey();
		}
		static void MapStudents()
		{
			SqlCommand cmd = new SqlCommand("exec sp_GetMyStudents", sqlConnection);
			// SqlCommand cmd = new SqlCommand("exec sp_GetStudents", sqlConnection);

			sqlConnection.Open();

			SqlDataReader reader = cmd.ExecuteReader();//obiekt !!

			while (reader.Read())
			{

				Student s = new Student();
				s.Id = Convert.ToInt32(reader["Id"]);
				s.Name = reader["Name"].ToString();
				s.NrAlbumu = Convert.ToInt32(reader["NrAlbumu"]);
				students.Add(s);
			}
			sqlConnection.Close();

		}
		static void InsertStudent()
		{
			Console.WriteLine("Podaj imie studenta");
			string studentName = Console.ReadLine();
			Console.WriteLine("Podaj nr albumu");
			string NrAlbumu = Console.ReadLine();
			Console.WriteLine("Podaj nr id szkoły");
			string schoolId = Console.ReadLine();

			string insertStud = string.Format("INSERT INTO Student(Name,NrAlbumu,SchoolId) VALUES ('{0}',{1},{2})",
			studentName, NrAlbumu, schoolId);
			SqlCommand cmd = new SqlCommand(insertStud, sqlConnection);
			sqlConnection.Open();
            cmd.ExecuteNonQuery();
			sqlConnection.Close();
		}
		static void ReadAndDisplayData(SqlDataReader reader)
		{
			while(reader.Read())
			{
					Console.WriteLine(reader["Id"].ToString() + " " +
					reader["Name"].ToString() + " " +
					reader["NrAlbumu"].ToString());
			}
			reader.Close();
			sqlConnection.Close();

		}
		static void ShowAllStudents()
		{
			SqlCommand cmd = new SqlCommand("SELECT * FROM Student ", sqlConnection);
			// SqlCommand cmd = new SqlCommand("exec sp_GetStudents", sqlConnection);

			sqlConnection.Open();

			SqlDataReader reader = cmd.ExecuteReader();//obiekt !!
			ReadAndDisplayData(reader);

		}
		static void SearchByAlbum(int album)
		{
			
			SqlCommand cmd = new SqlCommand("SELECT * FROM Student Where NrAlbumu = " + album.ToString(),
				sqlConnection);

			sqlConnection.Open();

			SqlDataReader reader = cmd.ExecuteReader();
			ReadAndDisplayData(reader);
		}
		public static void DoSth()
		{
			/*int a = 1;
			string name = "Abc";
			Student s = new Student();*/
		}
		static void InsertStudent_V2()
		{
			Console.WriteLine("Podaj imie studenta");
			string studentName = Console.ReadLine();
			Console.WriteLine("Podaj nr albumu");
			string NrAlbumu = Console.ReadLine();
			Console.WriteLine("Podaj nr id szkoły");
			string schoolId = Console.ReadLine();

			string insert = "INSERT INTO Student(Name, NrAlbumu,schoolId) VALUES (@name,@NrAlbumu,@SchoolId)";
			SqlCommand cmd = new SqlCommand(insert, sqlConnection);

			cmd.Parameters.Add("@Name", System.Data.SqlDbType.NVarChar).Value = studentName;
			cmd.Parameters.Add("@NrALbumu", System.Data.SqlDbType.NVarChar).Value = NrAlbumu;
			cmd.Parameters.Add("@SchoolId", System.Data.SqlDbType.NVarChar).Value = schoolId;

			sqlConnection.Open();
			cmd.ExecuteNonQuery();
			sqlConnection.Close();
		}
	}

}


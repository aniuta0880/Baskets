﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SolidApp
{
    public class BrozneCustomer: CustomerV2, IDiscount
    {
        public BrozneCustomer(ILogger logger) : base(logger)
        {

        }
        public  double GetDiscount()
        {
            return 0.2;
        }
    
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using static SolidApp.Vechicle;
using static SolidApp.Customer;

namespace SolidApp
{
    class Program
    {
        static void Main(string[] args)
        {

            /*Car car = new Car();
            car.FuelConsumption(10);
            MotorBike bike = new MotorBike();
            bike.FuelConsumption(10); */
            //AddCustomerToDB(0);
            //Customer cust = new Customer();
            //cust.AddCustomerToDB(0);
            GoldCustomer goldCustomer = new GoldCustomer(new SmsLogger());
            SilverCustomer silverCustomer = new SilverCustomer(new EmailLogger());
            BrozneCustomer brozneCustomer = new BrozneCustomer(new FileLogger());

        }
        private static void AddCustomerToDB(int v)
        {
          
        }
    }
}

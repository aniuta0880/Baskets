﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SolidApp
{
    public class Customer
    {
        private FileLogger logger = new FileLogger();
        public int CustomerType { get; set; }
        public double GetDiscount()
        {   //1-good
            //2-middle
            //3-new cust
            if(CustomerType == 1)
            {
                return 0.3;
            }
            else if(CustomerType == 2)
            {
                return 0.2;
            }
            else if(CustomerType==3)
            { 
                return 0.1;
            }
            else 
            {
                return 0;
            }
        }
        public void AddCustomerToDB(int value)
        {
            try
            {
                //do sth
                int a = 1 / value ; //DODAJ CUSTOMERA
            }
            catch(Exception ex)
            {
               // logger.LogMessageToFile(ex.Message);  
            }
        
        }
    }
}

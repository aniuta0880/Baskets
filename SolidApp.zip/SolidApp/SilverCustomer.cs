﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SolidApp
{
    public class SilverCustomer:CustomerV2, IDiscount
    {
        public SilverCustomer(ILogger logger) : base(logger) //Słowo kluczowe base służy do uzyskiwania dostępu do składowych klasy bazowej z poziomu klasy pochodnej: Wywołaj metodę w klasie bazowej, która została zastąpiona przez inną metodę
        {

        }
        public double GetDiscount()
        {
            return 0.2;
        }
    }
}

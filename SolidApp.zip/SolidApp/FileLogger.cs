﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SolidApp
{
    public interface ILogger
    {
        void LogMessage(string message);
    }
    public class FileLogger : ILogger
    {
        public void LogMessage(string message)
        {
            System.IO.File.WriteAllText(@"C:\path.txt", message);
        }
    }
    public class EmailLogger:ILogger
    {
        public void LogMessage(string message)
        {
            //send email to manager 
        }
    }
    public class SmsLogger:ILogger
    {
        public void LogMessage(string message)
        {
            //send sms to manager 
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SolidApp
{
     public abstract class Vechicle
    {
        public double MaxSpeed { get; set; }
        public double Fuel { get; set; }
        public double Distance { get; set; }

        public double AvgFuelConsumption { get; set; }

        public void Travel(double km)
        {   //distance = distance + km;
            Distance += km;
        }
        public virtual void FuelConsumption(double km) // możesz ją nadpisać 
        {
            double tmp = (km * AvgFuelConsumption) / 100;
            Fuel = Fuel - tmp;
        }
        public class Car: Vechicle
        {
            public override void FuelConsumption(double km)
            {
                double tmp = (km * AvgFuelConsumption) / 100;
                Fuel = (Fuel - tmp) / 2;
            }
        }
        public class MotorBike: Vechicle
        {
            public override void FuelConsumption(double km)
            {
               
            }
        }
        interface ICar
        {
            double GetMaxSpeed();
           
        }
        interface ICar2
        {
            void GiveSound();
        }


    }
}

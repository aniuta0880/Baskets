﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SolidApp
{
    public class GoldCustomer : CustomerV2, IMeeting
    {
        public GoldCustomer(ILogger logger): base(logger)
        {

        }
        public double GetDiscount()
        {
            return 0.2;
        }

        public void SetUpMeeting()
        {
            throw new NotImplementedException();
        }
    }
}

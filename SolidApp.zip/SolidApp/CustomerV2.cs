﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SolidApp
{
    public abstract class CustomerV2
    {
        public ILogger logger; //zmienna o typie interfejsu,
        public CustomerV2(ILogger _logger)
        {
            logger = _logger;
        }
        public string Name { get; set; }
        public string NIP { get; set; }
        public string EmailAdress { get; set; }
        
    }
    public interface IDiscount
    {
        double GetDiscount();
    }
    public interface IMeeting : IDiscount
    {
        void SetUpMeeting();
    }
    public class Enquiry: CustomerV2
    {
        public Enquiry(ILogger logger) : base(logger)
        {

        }

    }
}

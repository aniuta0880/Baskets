﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace ConsoleApp2
{
    class Program
    {
        static string connectionString = "Data Source=DESKTOP-OFK5IM7\\SQLEXPRESS;Initial Catalog=NORTHWND;Integrated Security=true";
        static SqlConnection sqlConnection = new SqlConnection(connectionString);

        public static void InsertRecord()
           {
           
                Console.WriteLine("Podaj OrderID");
                string order_id = Console.ReadLine();
                Console.WriteLine("Podaj CustomerID");
                string customer_id = Console.ReadLine();
                Console.WriteLine("Podaj EmployeeID");
                string employee_id = Console.ReadLine();
                //string employee_id = Console.ReadLine(); ?? klucz obcy 

                string insert = "INSERT INTO Orders(OrderID,CustomerID, EmployeeID)VALUES(@order_id, @customer_id, @employee_id)";
                SqlCommand cmd = new SqlCommand(insert, sqlConnection);

                cmd.Parameters.Add("@order_id", System.Data.SqlDbType.Int).Value = order_id;
                cmd.Parameters.Add("@customer_id", System.Data.SqlDbType.Int).Value = customer_id;
                //cmd.Parameters.Add("@employee_id", System.Data.SqlDbType.Int).Value = employee_id;

                sqlConnection.Open();
                cmd.ExecuteNonQuery();
                sqlConnection.Close();          
            
        }
    }
}
